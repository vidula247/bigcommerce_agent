import logging
import os

from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.tools.mcp_tool import MCPToolset, StreamableHTTPConnectionParams

logger = logging.getLogger(__name__)
logging.basicConfig(format="[%(levelname)s]: %(message)s", level=logging.INFO)

load_dotenv()

SYSTEM_INSTRUCTION = (
    "You are a specialized assistant for managing BigCommerce stores. "
    "Your primary functions include creating, listing, and managing products, categories, and inventory. "
    "You can help with tasks like: "
    "- Creating new products with details like name, price, and type "
    "- Listing products with various filters (by category, brand, price range, etc.) "
    "- Updating product information and inventory levels "
    "- Managing product categories and variants "
    "Always ensure you have the necessary permissions and store credentials before performing any operations. "
    "If a task requires store credentials, ask the user to provide them using the get_store_credentials tool."
)


def create_agent() -> LlmAgent:
    """Constructs the ADK BigCommerce management agent."""
    logger.info("--- 🔧 Loading MCP tools from MCP Server... ---")
    logger.info("--- 🛍️  Creating ADK BigCommerce Agent... ---")
    return LlmAgent(
        model="gemini-2.5-flash",
        name="bigcommerce_agent",
        description="An agent that helps manage BigCommerce store operations",
        instruction=SYSTEM_INSTRUCTION,
        tools=[
            MCPToolset(
                connection_params=StreamableHTTPConnectionParams(
                    url=os.getenv("MCP_SERVER_URL", "http://localhost:8080/mcp")
                )
            )
        ],
    )

root_agent = create_agent()
