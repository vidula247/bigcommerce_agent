from fastmcp import FastMCP
from typing import Any, Optional, Dict
from typing import List
from mcp.types import TextContent
import mysql.connector
import asyncio
mcp = FastMCP("BigCommerceMCP",require_api_key=False)
import httpx
import base64
import sys
import os
import asyncio
from pprint import pprint

global STORE_HASH 
global ACCESS_TOKEN 


##################
##################
##################
# HELPERS FOR PRODUCT
##################
##################
##################
async def make_bc_request(method: str, endpoint: str, json_data: Any = None) -> Any:
    
    global STORE_HASH
    global ACCESS_TOKEN
    BASE_URL = f"https://api.bigcommerce.com/stores/{STORE_HASH}/v3/catalog/products"
    HEADERS = {
    "X-Auth-Token": ACCESS_TOKEN,
    "Accept": "application/json",
    "Content-Type": "application/json"
}
    url = f"{BASE_URL}{endpoint}"
    print("Store Hash:", STORE_HASH)
    print("Access Token:", ACCESS_TOKEN)
    print("Making request to:", url)
    print("Headers:", HEADERS)
    async with httpx.AsyncClient() as client:
        try:
            response = await client.request(method, url, headers=HEADERS, json=json_data, timeout=30.0)
            print(response.json())
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            print(f"HTTP error: {e.response.status_code} - {e.response.text}")
            return {"error": f"HTTP error: {e.response.status_code} - {e.response.text}"}
        except Exception as e:
            print(f"Error: {str(e)}")
            return {"error": str(e)}

@mcp.tool(description="Fetches StoreHash and Access Token for BigCommerce. Get Store ID from the user.")
def get_store_credentials(store_id: int) -> Optional[Dict[str, str]]:
    """
    Fetch store_hash and access_token from app_stores table using store ID
    
    Args:
        store_id: The ID of the store
    Returns:
        Success message or None
    """
    try:
        global STORE_HASH
        global ACCESS_TOKEN
        connection = mysql.connector.connect(
            charset="utf8mb4",
            host=os.environ.get("DB_HOST", "158.220.93.14"),
            port=int(os.environ.get("DB_PORT", 3407)),
            user=os.environ.get("DB_USER", "root"),
            password=os.environ.get("DB_PASS", "ZasHZLBznK0T"),
            database=os.environ.get("DB_NAME", "shopify_stagingpro_dev")
        )
        
        cursor = connection.cursor(dictionary=True)
        
        query = "SELECT store_hash, access_token FROM app_stores WHERE id = %s"
        cursor.execute(query, (store_id,))
        
        result = cursor.fetchone()
        
        if result:
            
            STORE_HASH = result["store_hash"]
            ACCESS_TOKEN = result["access_token"]
            
            return "Store Initialized Successfully"
        return None
    
    except mysql.connector.Error as err:
        print(f"Database error: {err}")
        return None
        
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'connection' in locals() and connection.is_connected():
            connection.close()




##################
##################
##################
# PRODUCTS TOOLS
##################
##################
##################
@mcp.tool(description="Creates a new Product in BigCommerce. Product Name is Required. Other fields are optional.If not Mentioned, default values will be used.")
async def create_product(product_data: dict) -> dict:
    """Create a new product with the given fields.
    Required fields: name, type,weight,price
    Ask User for the required fields if not provided.
    """
    result = await make_bc_request("POST", "", product_data)
    if "data" in result and isinstance(result["data"], dict):
        filtered_response = {
            "id": result["data"].get("id"),
            "name": result["data"].get("name")
        }
        return filtered_response
    return result

##########FILTER PRODUCTS
@mcp.tool(description="List products from BigCommerce with all supported filters.")
async def list_products(
    filters: dict = None,
    page: int = 1,
    limit: int = 50
) -> dict:
    """
    List products from BigCommerce using flexible filters.

    Args:
        filters (dict, optional): BigCommerce-supported query filters. Examples include:
            - 'id:in', 'name', 'sku', 'categories:in', 'brand_id', 'price:min', 'price:max'
            - 'inventory_level:min', 'inventory_level:max', 'is_visible', 'is_featured'
            - 'type', 'availability', 'date_created:min', 'date_modified:max', 'search', etc.
        page (int): Page number (default 1).
        limit (int): Number of products per page (default 50).

    Returns:
        dict: API response or error info.
    """
    global STORE_HASH, ACCESS_TOKEN

    BASE_URL = f"https://api.bigcommerce.com/stores/{STORE_HASH}/v3/catalog/products"
    HEADERS = {
        "X-Auth-Token": ACCESS_TOKEN,
        "Accept": "application/json"
    }

    params = {"page": page, "limit": limit}
    if filters:
        params.update(filters)

    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(BASE_URL, headers=HEADERS, params=params, timeout=30.0)
            response.raise_for_status()
            data = response.json()

            products_summary = [
                {
                    "id": prod.get("id"),
                    "name": prod.get("name"),
                    "price": prod.get("price"),
                    "inventory_level": prod.get("inventory_level"),
                    "categories": prod.get("categories"),
                    "brand_id": prod.get("brand_id"),
                    "date_created": prod.get("date_created")
                }
                for prod in data.get("data", [])
            ]

            return {
                "success": True,
                "page": data.get("meta", {}).get("pagination", {}).get("current_page", page),
                "limit": limit,
                "total_products": data.get("meta", {}).get("pagination", {}).get("total", len(products_summary)),
                "products": products_summary
            }
        except httpx.HTTPStatusError as e:
            return {"error": f"HTTP {e.response.status_code}", "details": e.response.text}
        except Exception as e:
            return {"error": str(e)}

##########GET PRODUCT DETAILS FOR ONE PRODUCT
@mcp.tool(description="Retrieve a product by its ID.")
async def get_product(product_id: int) -> dict:
    """Retrieve a product by its ID.
    Required fields: product_id
    Ask User for the product_id if not provided.
    """
    result = await make_bc_request("GET", f"/{product_id}")
    return result






if __name__ == "__main__":
    logger.info(f"🚀 MCP server started on port {os.getenv('PORT', 8080)}")
    # Could also use 'sse' transport, host="0.0.0.0" required for Cloud Run.
    asyncio.run(
        mcp.run_async(
            transport="streamable-http",
            host="0.0.0.0",
            port=os.getenv("PORT", 8080),
        )
    )