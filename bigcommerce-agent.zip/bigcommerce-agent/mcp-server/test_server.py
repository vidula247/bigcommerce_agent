import asyncio
from fastmcp import Client


async def test_server():
    # Test the MCP server using streamable-http transport
    async with Client("http://localhost:8080/mcp") as client:
        # List available tools
        tools = await client.list_tools()
        print("\n--- 🛠️  Available Tools ---")
        for tool in tools:
            print(f"- {tool.name}: {tool.description}")

        # Initialize store credentials
        print("\n--- 🔑  Initializing Store Credentials ---")
        store_id = int(input("Enter Store ID: "))
        init_result = await client.call_tool(
            "get_store_credentials", 
            {"store_id": store_id}
        )
        print(f"Initialization Result: {init_result}")

        # List products
        print("\n--- 🛍️  Listing Products ---")
        products = await client.call_tool(
            "list_products", 
            {"page": 1, "limit": 5}
        )
        print("Products:")
        for product in products.get('products', []):
            print(f"- {product['name']} (ID: {product['id']}, Price: {product.get('price', 'N/A')})")
        
        print("\n✅ Test completed successfully!")


if __name__ == "__main__":
    asyncio.run(test_server())
